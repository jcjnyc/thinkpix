#!/bin/bash

cd /usr/local/thinkpix;./plasma_server.pl "power off" all;
