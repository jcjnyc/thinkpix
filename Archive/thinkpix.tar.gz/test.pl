#!/usr/bin/perl

$in = <STDIN>;
print $in;
<STDIN>;
