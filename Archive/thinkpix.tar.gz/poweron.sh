#!/bin/bash

cd /usr/local/thinkpix;
./plasma_server.pl "power on" all;